<?php
$DisplayData = new DisplayData;
$Helpers = new Helpers;
$GetData = new GetData;
$SVG = new SVG;
$testimonials_arr = array();
if ($type == 'product-reviews') {
    $testimonials = carbon_get_the_post_meta('reviews');
    foreach ($testimonials as $testimonial) {
        $testimonials_arr[] = array(
            'author' => $testimonial['author'],
            'description' => $testimonial['review_content']
        );
    }
} else {
    $testimonials = $GetData->get_posts_ids('testimonials');
    foreach ($testimonials as $key => $testimonial) {
        $testimonials_arr[] = array(
            'author' => $testimonial,
            'description' => get__post_meta_by_id($key, 'testimonial_content')
        );
    }
}
$testimonial_heading = get__theme_option('testimonial_heading');
$testimonial_rating = get__theme_option('testimonial_rating');
?>

<?php if ($type != 'product-reviews' && $type != 'case-study') { ?>
    <div class="container">
        <div class="row g-4 white-color mb-7 justify-content-between">
            <div class="col-auto ">
                <span class="text-style-1  left fw-medium">
                    COPTRZ CUSTOMER REVIEWS
                </span>
            </div>
            <div class="col-auto">
                <div class="heading-box mb-6">
                    <h2>
                        <?= $testimonial_heading ?>
                    </h2>

                </div>
                <div class="review-score d-flex align-items-center">
                    <div class="score">
                    <?= $testimonial_rating ?>
                    </div>
                    <div class="stars-holder">
                        <div class="stars d-flex">
                            <?php SVG::star() ?>
                            <?php SVG::star() ?>
                            <?php SVG::star() ?>
                            <?php SVG::star() ?>
                            <?php SVG::star_half() ?>
                        </div>
                        <div class="star-text">
                            <span>Score on <a targe="_blank" style="color: #fff" href="https://www.google.com/search?q=coptrz+google+review&rlz=1C1VDKB_enPH1019PH1019&oq=coptrz+google+review&aqs=chrome..69i57j69i64l2.3639j0j7&sourceid=chrome&ie=UTF-8">Google</a></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php  } ?>
<div class="review-holder <?= $type == 'case-study' ? 'review-holder-case-study' : '' ?>">
    <div class="swiper  mySwiper-Reviews <?= $class ? $class : 'mySwiper-ReviewsDefault' ?>">
        <div class="swiper-wrapper align-items-center">
            <?php foreach ($testimonials_arr as $testimonial) { ?>
                <div class="swiper-slide">
                    <div class="review-box <?= $type == 'case-study' ? '' : 'background-secondary' ?> d-flex">
                        <div class="quote">
                            <?php SVG::quote() ?>
                        </div>
                        <div class="review-content">
                            <?php
                            $DisplayData->description(
                                array(
                                    'description' => $testimonial['description'],
                                ),
                                'review-text'
                            );
                            ?>
                            <div class="author d-flex align-items-center">
                                <span>
                                    <?= $testimonial['author'] ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

            <?php } ?>
        </div>
        <?php if ($type == 'case-study') { ?>
            <div class="swiper-pagination d-flex justify-content-center align-items-center"></div>
        <?php } ?>
    </div>
</div>