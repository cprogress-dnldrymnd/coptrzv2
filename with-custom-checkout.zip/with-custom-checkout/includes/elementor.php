<?php
function register_new_widgets($widgets_manager)
{
	require_once(__DIR__ . '/elementor-widgets/brands-slider/brands-slider.php');
	$widgets_manager->register(new \Elementor_Brands_Slider());
}
add_action('elementor/widgets/register', 'register_new_widgets');



function add_elementor_widget_categories($elements_manager)
{

	$elements_manager->add_category(
		'Coptrz',
		[
			'title' => esc_html__('Coptrz', 'textdomain'),
			'icon'  => 'fa fa-plug',
		]
	);

}
add_action('elementor/elements/categories_registered', 'add_elementor_widget_categories');